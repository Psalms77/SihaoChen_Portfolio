A remake of Journey's camera control system in Unity. 

Controller Recommended!!!

and here's the analysis: https://docs.google.com/document/d/1OjQZSWW0Evca0rPNZikrXHphwAlIEotPsTKDzND5fyc/edit?usp=sharing 

Made by Sihao Chen